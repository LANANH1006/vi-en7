package com.viexplorer.recipehelper.client;

import com.viexplorer.recipehelper.client.SmeltingData.Recipe;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.FurnaceScreen;
import net.minecraft.item.ItemStack;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/**
 * Bảng bên phải lò nung: ô tìm kiếm ở trên, danh sách các thứ nung ra được bên dưới.
 * Mỗi dòng: [đầu vào] > [kết quả]. Di chuột vào icon để xem tên vật phẩm.
 */
public final class FurnacePanel {

    private static final int PANEL_W = 150;
    private static final int PANEL_H = 166;
    private static final int SEARCH_H = 14;
    private static final int LIST_TOP = 34;
    private static final int ROW_H = 20;
    private static final int SCROLL_STEP = 12;

    private static String query = "";
    private static boolean searchFocused = true;
    private static int scrollPx = 0;

    private FurnacePanel() {}

    /** Đúng khi đang ở màn hình lò nung và ô tìm kiếm đang được chọn. */
    public static boolean isTypingInSearch() {
        return ModConfig.furnaceOn() && searchFocused
                && MinecraftClient.getInstance().currentScreen instanceof FurnaceScreen;
    }

    private static int panelX(int screenW) {
        return screenW / 2 + 96;
    }

    private static int panelY(int screenH) {
        return screenH / 2 - PANEL_H / 2;
    }

    private static int listH() {
        return PANEL_H - LIST_TOP - 4;
    }

    public static void render(DrawContext ctx, TextRenderer tr, int screenW, int screenH, int mouseX, int mouseY) {
        int x = panelX(screenW);
        int y = panelY(screenH);

        ctx.fill(x, y, x + PANEL_W, y + PANEL_H, 0xD0101010);
        ctx.drawBorder(x, y, PANEL_W, PANEL_H, 0xFF8B8B8B);

        // Ô tìm kiếm
        int sx = x + 4, sy = y + 4, sw = PANEL_W - 8;
        ctx.fill(sx, sy, sx + sw, sy + SEARCH_H, searchFocused ? 0xFF3A3A3A : 0xFF202020);
        ctx.drawBorder(sx, sy, sw, SEARCH_H, searchFocused ? 0xFFFFFFFF : 0xFF555555);
        if (query.isEmpty() && !searchFocused) {
            ctx.drawText(tr, "Tìm kiếm...", sx + 3, sy + 3, 0xFF777777, false);
        } else {
            String shown = tr.trimToWidth(query, sw - 8);
            if (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0) {
                shown = shown + "_";
            }
            ctx.drawText(tr, shown, sx + 3, sy + 3, 0xFFFFFFFF, false);
        }

        List<Recipe> rs = SmeltingData.search(query);
        String header = query.isEmpty() ? "Gõ tên để tìm, ví dụ: đất sét" : "Công thức tìm được: " + rs.size();
        ctx.drawText(tr, tr.trimToWidth(header, PANEL_W - 8), x + 4, y + 22, 0xFFAAAAAA, false);

        int lh = listH();
        int total = rs.size() * ROW_H;
        int maxScroll = Math.max(0, total - lh);
        scrollPx = Math.max(0, Math.min(scrollPx, maxScroll));

        int lx1 = x + 2, ly1 = y + LIST_TOP, lx2 = x + PANEL_W - 2, ly2 = ly1 + lh;
        boolean inList = inside(mouseX, mouseY, lx1, ly1, lx2 - lx1, lh);
        ItemStack hoveredIcon = ItemStack.EMPTY;

        if (rs.isEmpty()) {
            ctx.drawText(tr, "Không có công thức nào", x + 8, ly1 + 6, 0xFF888888, false);
        } else {
            ctx.enableScissor(lx1, ly1, lx2, ly2);
            int top = ly1 - scrollPx;
            for (Recipe r : rs) {
                if (top + ROW_H > ly1 && top < ly2) {
                    if (inList && mouseY >= top && mouseY < top + ROW_H) {
                        ctx.fill(lx1, top, lx2 - 4, top + ROW_H, 0x40FFFFFF);
                    }
                    ctx.drawItem(r.input(), x + 6, top + 2);
                    ctx.drawText(tr, ">", x + 26, top + 6, 0xFFFFFFFF, false);
                    ctx.drawItem(r.output(), x + 36, top + 2);
                    ctx.drawText(tr, tr.trimToWidth(r.output().getName().getString(), PANEL_W - 60),
                            x + 56, top + 6, 0xFFDDDDDD, false);
                    if (inList && hoveredIcon.isEmpty()) {
                        if (inside(mouseX, mouseY, x + 6, top + 2, 16, 16)) {
                            hoveredIcon = r.input();
                        } else if (inside(mouseX, mouseY, x + 36, top + 2, 16, 16)) {
                            hoveredIcon = r.output();
                        }
                    }
                }
                top += ROW_H;
            }
            ctx.disableScissor();
        }

        // Thanh cuộn
        if (maxScroll > 0) {
            int barH = Math.max(12, lh * lh / total);
            int barY = ly1 + (lh - barH) * scrollPx / maxScroll;
            ctx.fill(x + PANEL_W - 4, barY, x + PANEL_W - 2, barY + barH, 0xFFAAAAAA);
        }

        // Di chuột vào icon: hiện tên vật phẩm để biết đó là gì
        if (!hoveredIcon.isEmpty()) {
            ctx.drawTooltip(tr, List.of(hoveredIcon.getName()), mouseX, mouseY);
        }
    }

    /** Nhấn chuột: chọn ô tìm kiếm nếu bấm vào đó, bỏ chọn nếu bấm ra ngoài. Trả về true nếu chuột trong bảng. */
    public static boolean click(int screenW, int screenH, double mouseX, double mouseY) {
        int x = panelX(screenW), y = panelY(screenH);
        if (!inside(mouseX, mouseY, x, y, PANEL_W, PANEL_H)) {
            searchFocused = false;
            return false;
        }
        searchFocused = inside(mouseX, mouseY, x + 4, y + 4, PANEL_W - 8, SEARCH_H);
        return true;
    }

    /** Cuộn danh sách. Trả về true nếu chuột nằm trong bảng. */
    public static boolean scroll(int screenW, int screenH, double mouseX, double mouseY, double vertical) {
        int x = panelX(screenW), y = panelY(screenH);
        if (!inside(mouseX, mouseY, x, y, PANEL_W, PANEL_H)) {
            return false;
        }
        scrollPx -= (int) (vertical * SCROLL_STEP);
        if (scrollPx < 0) {
            scrollPx = 0;
        }
        return true;
    }

    /** Nhận ký tự gõ vào khi ô tìm kiếm đang được chọn. */
    public static boolean charTyped(char chr) {
        if (!isTypingInSearch() || Character.isISOControl(chr)) {
            return false;
        }
        query = query + chr;
        scrollPx = 0;
        return true;
    }

    /** Xử lý phím khi đang gõ tìm kiếm. Trả về true để chặn phím tắt của game (ví dụ phím E đóng màn hình). */
    public static boolean keyPressed(int keyCode) {
        if (!isTypingInSearch()) {
            return false;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            return false; // ESC vẫn đóng màn hình như bình thường
        }
        if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !query.isEmpty()) {
            query = query.substring(0, query.length() - 1);
            scrollPx = 0;
        }
        return true;
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
}
