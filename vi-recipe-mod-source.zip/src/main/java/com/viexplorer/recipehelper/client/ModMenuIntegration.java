package com.viexplorer.recipehelper.client;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/** Đăng ký màn hình cài đặt với Mod Menu. Chỉ được gọi khi người chơi đã cài Mod Menu. */
public class ModMenuIntegration implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> new VIConfigScreen(parent);
    }
}
