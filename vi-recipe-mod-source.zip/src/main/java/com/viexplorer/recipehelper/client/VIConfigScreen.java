package com.viexplorer.recipehelper.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;

/**
 * Màn hình bật/tắt mod, mở từ Mod Menu.
 * Thay đổi được lưu ngay; tính năng nào tắt sẽ không hiện ở màn hình tương ứng nữa.
 */
public final class VIConfigScreen extends Screen {

    private final Screen parent;

    public VIConfigScreen(Screen parent) {
        super(Text.literal("Vi Recipe Helper"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int bw = 200;
        int bx = this.width / 2 - bw / 2;
        int y = 36;
        addToggle(bx, y, bw, "Bật mod", () -> ModConfig.master, () -> ModConfig.master = !ModConfig.master);
        y += 26;
        addToggle(bx, y, bw, "Giàn pha thuốc", () -> ModConfig.brewing, () -> ModConfig.brewing = !ModConfig.brewing);
        y += 26;
        addToggle(bx, y, bw, "Bàn phù phép", () -> ModConfig.enchant, () -> ModConfig.enchant = !ModConfig.enchant);
        y += 26;
        addToggle(bx, y, bw, "Bàn nâng cấp", () -> ModConfig.smithing, () -> ModConfig.smithing = !ModConfig.smithing);
        y += 26;
        addToggle(bx, y, bw, "Lò nung", () -> ModConfig.furnace, () -> ModConfig.furnace = !ModConfig.furnace);
        y += 36;
        addDrawableChild(ButtonWidget.builder(Text.literal("Xong"), b -> close())
                .dimensions(bx, y, bw, 20)
                .build());
    }

    private void addToggle(int x, int y, int w, String name, BooleanSupplier get, Runnable flip) {
        addDrawableChild(ButtonWidget.builder(label(name, get), b -> {
            flip.run();
            ModConfig.save();
            b.setMessage(label(name, get));
        }).dimensions(x, y, w, 20).build());
    }

    private static Text label(String name, BooleanSupplier get) {
        return Text.literal(name + ": " + (get.getAsBoolean() ? "BẬT" : "TẮT"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx, mouseX, mouseY, delta);
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 16, 0xFFFFFF);
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }
}
