package com.viexplorer.recipehelper.client;

import com.viexplorer.recipehelper.client.BrewingData.Entry;
import com.viexplorer.recipehelper.client.BrewingData.Guide;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.BrewingStandScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Bảng bên phải giàn chế thuốc: ô tìm kiếm ở trên, danh sách thuốc bên dưới.
 * Bấm vào một thuốc để mở đường pha từ thuốc nước, mỗi bước là một dòng icon 2D:
 * [thuốc gốc] + [nguyên liệu] = [thuốc kết quả].
 */
public final class BrewingPanel {

    private static final int PANEL_W = 150;
    private static final int PANEL_H = 166;
    private static final int SEARCH_H = 14;
    private static final int LIST_TOP = 34;
    private static final int ROW_H = 22;
    private static final int STEP_H = 24;
    private static final int SCROLL_STEP = 12;
    private static final int AUTO_OPEN_LIMIT = 4;

    private static String query = "";
    private static boolean searchFocused = true;
    private static int scrollPx = 0;
    private static final Set<String> OPEN = new HashSet<>();

    private BrewingPanel() {}

    public static void reset() {
        query = "";
        searchFocused = true;
        scrollPx = 0;
        OPEN.clear();
    }

    /** Đúng khi người chơi đang ở màn hình giàn chế thuốc và ô tìm kiếm đang được chọn. */
    public static boolean isTypingInSearch() {
        return ModConfig.brewingOn() && searchFocused
                && MinecraftClient.getInstance().currentScreen instanceof BrewingStandScreen;
    }

    private static int panelX(int screenW) {
        return screenW / 2 + 96;
    }

    private static int panelY(int screenH) {
        return screenH / 2 - PANEL_H / 2;
    }

    private static int listH() {
        return PANEL_H - LIST_TOP - 4;
    }

    private static int rowHeight(Guide g) {
        return ROW_H + (OPEN.contains(g.viName()) ? g.steps().size() * STEP_H + 4 : 0);
    }

    private static int totalHeight(List<Guide> gs) {
        int total = 0;
        for (Guide g : gs) {
            total += rowHeight(g);
        }
        return total;
    }

    /** Gọi khi từ khóa thay đổi: đưa về đầu danh sách, và tự mở đường pha nếu ít kết quả. */
    private static void queryChanged() {
        scrollPx = 0;
        if (!query.isEmpty()) {
            List<Guide> gs = BrewingData.guides(query);
            if (gs.size() <= AUTO_OPEN_LIMIT) {
                for (Guide g : gs) {
                    OPEN.add(g.viName());
                }
            }
        }
    }

    public static void render(DrawContext ctx, TextRenderer tr, int screenW, int screenH, int mouseX, int mouseY) {
        int x = panelX(screenW);
        int y = panelY(screenH);

        ctx.fill(x, y, x + PANEL_W, y + PANEL_H, 0xD0101010);
        ctx.drawBorder(x, y, PANEL_W, PANEL_H, 0xFF8B8B8B);

        // Ô tìm kiếm
        int sx = x + 4, sy = y + 4, sw = PANEL_W - 8;
        ctx.fill(sx, sy, sx + sw, sy + SEARCH_H, searchFocused ? 0xFF3A3A3A : 0xFF202020);
        ctx.drawBorder(sx, sy, sw, SEARCH_H, searchFocused ? 0xFFFFFFFF : 0xFF555555);
        if (query.isEmpty() && !searchFocused) {
            ctx.drawText(tr, "Tìm thuốc...", sx + 3, sy + 3, 0xFF777777, false);
        } else {
            String shown = tr.trimToWidth(query, sw - 8);
            if (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0) {
                shown = shown + "_";
            }
            ctx.drawText(tr, shown, sx + 3, sy + 3, 0xFFFFFFFF, false);
        }

        List<Guide> gs = BrewingData.guides(query);
        String header = query.isEmpty() ? "Gõ tên thuốc, ví dụ: thuốc sức mạnh" : "Thuốc tìm được: " + gs.size();
        // DEBUG tạm thời: số ký tự nhận được và trạng thái ô tìm kiếm (sẽ gỡ sau khi test xong)
        ctx.drawText(tr, tr.trimToWidth("DEBUG ký tự=" + CharInput.received() + " ô chọn=" + searchFocused
                + " | " + header, PANEL_W - 8), x + 4, y + 22, 0xFFFFFF00, false);

        int lh = listH();
        int total = totalHeight(gs);
        int maxScroll = Math.max(0, total - lh);
        scrollPx = Math.max(0, Math.min(scrollPx, maxScroll));

        int lx1 = x + 2, ly1 = y + LIST_TOP, lx2 = x + PANEL_W - 2, ly2 = ly1 + lh;
        ctx.enableScissor(lx1, ly1, lx2, ly2);

        boolean inList = inside(mouseX, mouseY, lx1, ly1, lx2 - lx1, lh);
        int top = ly1 - scrollPx;
        Guide hovered = null;
        ItemStack hoveredIcon = ItemStack.EMPTY;
        for (Guide g : gs) {
            int h = rowHeight(g);
            if (top + h > ly1 && top < ly2) {
                boolean hover = inList && mouseY >= top && mouseY < top + ROW_H;
                drawGuide(ctx, tr, g, x, top, hover);
                if (hover) {
                    hovered = g;
                }
                if (inList && hoveredIcon.isEmpty()) {
                    hoveredIcon = iconUnder(g, x, top, mouseX, mouseY);
                }
            }
            top += h;
        }
        ctx.disableScissor();

        // Thanh cuộn
        if (maxScroll > 0) {
            int barH = Math.max(12, lh * lh / total);
            int barY = ly1 + (lh - barH) * scrollPx / maxScroll;
            ctx.fill(x + PANEL_W - 4, barY, x + PANEL_W - 2, barY + barH, 0xFFAAAAAA);
        }

        if (!hoveredIcon.isEmpty()) {
            // Di chuột vào icon: hiện tên vật phẩm để biết đó là gì
            ctx.drawTooltip(tr, List.of(hoveredIcon.getName()), mouseX, mouseY);
        } else if (hovered != null) {
            boolean open = OPEN.contains(hovered.viName());
            ctx.drawTooltip(tr, List.of(
                    Text.literal(hovered.viName()),
                    Text.literal(open ? "Nhấn để thu gọn" : "Nhấn để xem cách pha")
            ), mouseX, mouseY);
        }
    }

    /** Một thuốc: icon + tên + dấu +/-. Nếu đang mở thì vẽ thêm từng bước pha bên dưới. */
    private static void drawGuide(DrawContext ctx, TextRenderer tr, Guide g, int x, int top, boolean hover) {
        boolean open = OPEN.contains(g.viName());
        if (hover) {
            ctx.fill(x + 2, top, x + PANEL_W - 6, top + ROW_H, 0x40FFFFFF);
        }
        ctx.drawItem(g.result(), x + 6, top + 3);
        ctx.drawText(tr, tr.trimToWidth(g.viName(), PANEL_W - 50), x + 26, top + 7, 0xFFDDDDDD, false);
        ctx.drawText(tr, open ? "-" : "+", x + PANEL_W - 14, top + 7, 0xFFFFFFFF, false);

        if (open) {
            int sy = top + ROW_H + 2;
            for (int i = 0; i < g.steps().size(); i++) {
                Entry e = g.steps().get(i);
                drawStep(ctx, tr, e, i + 1, x + 4, sy + i * STEP_H);
            }
        }
    }

    /** Một bước: số thứ tự, [gốc] + [nguyên liệu] = [kết quả], đều là icon 2D. */
    private static void drawStep(DrawContext ctx, TextRenderer tr, Entry e, int index, int x, int y) {
        ctx.drawText(tr, index + ".", x, y + 8, 0xFFAAAAAA, false);
        ctx.drawItem(e.base(), x + 14, y + 4);
        ctx.drawText(tr, "+", x + 32, y + 8, 0xFFFFFFFF, false);
        ctx.drawItem(e.ingredient(), x + 40, y + 4);
        ctx.drawText(tr, "=", x + 58, y + 8, 0xFFFFFFFF, false);
        ctx.drawItem(e.result(), x + 66, y + 4);
    }

    /**
     * Trả về vật phẩm của icon đang nằm dưới chuột (icon thuốc hoặc icon trong từng bước pha), nếu không có thì EMPTY.
     * Vị trí icon phải khớp với drawGuide và drawStep.
     */
    private static ItemStack iconUnder(Guide g, int x, int top, int mouseX, int mouseY) {
        if (inside(mouseX, mouseY, x + 6, top + 3, 16, 16)) {
            return g.result();
        }
        if (OPEN.contains(g.viName())) {
            int sy = top + ROW_H + 2;
            for (int i = 0; i < g.steps().size(); i++) {
                Entry e = g.steps().get(i);
                int iy = sy + i * STEP_H + 4;
                int sx = x + 4;
                if (inside(mouseX, mouseY, sx + 14, iy, 16, 16)) {
                    return e.base();
                }
                if (inside(mouseX, mouseY, sx + 40, iy, 16, 16)) {
                    return e.ingredient();
                }
                if (inside(mouseX, mouseY, sx + 66, iy, 16, 16)) {
                    return e.result();
                }
            }
        }
        return ItemStack.EMPTY;
    }

    /** Nhấn chuột: bấm vào một thuốc để mở/đóng đường pha. Trả về true nếu chuột nằm trong bảng. */
    public static boolean click(int screenW, int screenH, double mouseX, double mouseY) {
        int x = panelX(screenW), y = panelY(screenH);
        if (!inside(mouseX, mouseY, x, y, PANEL_W, PANEL_H)) {
            searchFocused = false;
            return false;
        }
        if (inside(mouseX, mouseY, x + 4, y + 4, PANEL_W - 8, SEARCH_H)) {
            searchFocused = true;
            return true;
        }
        searchFocused = false;

        int ly1 = y + LIST_TOP, ly2 = ly1 + listH();
        if (mouseY < ly1 || mouseY >= ly2) {
            return true;
        }
        int top = ly1 - scrollPx;
        for (Guide g : BrewingData.guides(query)) {
            if (mouseY >= top && mouseY < top + ROW_H) {
                if (OPEN.contains(g.viName())) {
                    OPEN.remove(g.viName());
                } else {
                    OPEN.add(g.viName());
                }
                return true;
            }
            top += rowHeight(g);
        }
        return true;
    }

    public static boolean scroll(int screenW, int screenH, double mouseX, double mouseY, double vertical) {
        int x = panelX(screenW), y = panelY(screenH);
        if (!inside(mouseX, mouseY, x, y, PANEL_W, PANEL_H)) {
            return false;
        }
        scrollPx -= (int) (vertical * SCROLL_STEP);
        if (scrollPx < 0) {
            scrollPx = 0;
        }
        return true;
    }

    /** Nhận ký tự gõ vào khi ô tìm kiếm đang được chọn. */
    public static boolean charTyped(char chr) {
        if (!isTypingInSearch() || Character.isISOControl(chr)) {
            return false;
        }
        query = query + chr;
        queryChanged();
        return true;
    }

    /** Xử lý phím khi đang gõ tìm kiếm. Trả về true để chặn phím tắt của game (ví dụ phím E đóng màn hình). */
    public static boolean keyPressed(int keyCode) {
        if (!isTypingInSearch()) {
            return false;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            return false; // ESC vẫn đóng màn hình như bình thường
        }
        if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !query.isEmpty()) {
            query = query.substring(0, query.length() - 1);
            queryChanged();
        }
        return true;
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
}
