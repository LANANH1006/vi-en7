package com.viexplorer.recipehelper.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.SmithingScreen;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ModelTransformationMode;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.util.math.RotationAxis;

/**
 * Bảng bên phải bàn nâng cấp.
 * - Ba ô nguyên liệu hiện bằng icon 2D.
 * - Khi có kết quả là giáp: hiện nhân vật của bạn (đúng skin) đang mặc bộ giáp đó.
 * - Khi kết quả không phải giáp: hiện vật phẩm 3D.
 * Kéo chuột trái trong khung xem trước để xoay 360 độ.
 */
public final class SmithingPanel {

    private static final int PANEL_W = 150;
    private static final int PANEL_H = 166;
    private static final int PREVIEW_H = 92;
    private static final int TEMPLATE_SLOT = 0;
    private static final int BASE_SLOT = 1;
    private static final int ADDITION_SLOT = 2;
    private static final int OUTPUT_SLOT = 3;
    private static final float PLAYER_SIZE = 30f;

    private static float angleX = 15f;
    private static float angleY = 30f;
    private static boolean dragging = false;

    /** Nhân vật giả (cùng skin với bạn) dùng để hiện giáp kết quả. */
    private static OtherClientPlayerEntity dummy = null;
    private static EquipmentSlot dummySlot = null;
    private static ItemStack dummyArmor = ItemStack.EMPTY;

    private SmithingPanel() {}

    public static void reset() {
        angleX = 15f;
        angleY = 30f;
        dragging = false;
        dummy = null;
        dummySlot = null;
        dummyArmor = ItemStack.EMPTY;
    }

    private static int panelX(int screenW) {
        return screenW / 2 + 96;
    }

    private static int panelY(int screenH) {
        return screenH / 2 - PANEL_H / 2;
    }

    public static void render(DrawContext ctx, TextRenderer tr, MinecraftClient client, ScreenHandler handler,
                              int screenW, int screenH) {
        int x = panelX(screenW);
        int y = panelY(screenH);
        ctx.fill(x, y, x + PANEL_W, y + PANEL_H, 0xD0101010);
        ctx.drawBorder(x, y, PANEL_W, PANEL_H, 0xFF8B8B8B);
        ctx.drawText(tr, "Xem trước nâng cấp", x + 4, y + 6, 0xFFFFFFFF, false);

        // Ba ô nguyên liệu, vẽ bằng icon 2D
        int iy = y + 20;
        int[] slots = {TEMPLATE_SLOT, BASE_SLOT, ADDITION_SLOT};
        String[] labels = {"Khuôn", "Gốc", "Thêm"};
        for (int i = 0; i < slots.length; i++) {
            int ix = x + 8 + i * 46;
            ItemStack s = handler.getSlot(slots[i]).getStack();
            ctx.fill(ix - 1, iy - 1, ix + 17, iy + 17, 0x40FFFFFF);
            ctx.drawItem(s, ix, iy);
            ctx.drawText(tr, labels[i], ix - 2, iy + 19, 0xFFAAAAAA, false);
        }

        // Khung xem trước
        int px = x + 4, py = y + 52, pw = PANEL_W - 8;
        ctx.fill(px, py, px + pw, py + PREVIEW_H, 0xFF151515);
        ctx.drawBorder(px, py, pw, PREVIEW_H, 0xFF555555);

        ItemStack out = handler.getSlot(OUTPUT_SLOT).getStack();
        if (out.isEmpty()) {
            ctx.drawText(tr, "Đặt đủ nguyên liệu", px + 14, py + 40, 0xFF888888, false);
            ctx.drawText(tr, "để xem kết quả", px + 22, py + 50, 0xFF888888, false);
        } else {
            ctx.enableScissor(px + 1, py + 1, px + pw - 1, py + PREVIEW_H - 1);
            EquippableComponent equippable = out.get(DataComponentTypes.EQUIPPABLE);
            if (equippable != null && client.player != null) {
                renderCharacter(ctx, client, out, equippable.slot(), px + pw / 2, py + PREVIEW_H - 6);
            } else {
                renderItem3D(ctx, client, out, px + pw / 2, py + PREVIEW_H / 2 + 4);
            }
            ctx.disableScissor();
            ctx.drawText(tr, "Kéo chuột để xoay", px + 4, py + PREVIEW_H - 10, 0xFF777777, false);
            ctx.drawText(tr, tr.trimToWidth(out.getName().getString(), PANEL_W - 8),
                    x + 4, y + PANEL_H - 12, 0xFFFFD700, false);
        }
    }

    /** Đảm bảo nhân vật giả đang mặc đúng bộ giáp kết quả. */
    private static OtherClientPlayerEntity ensureDummy(MinecraftClient client, ItemStack armor, EquipmentSlot slot) {
        if (dummy == null) {
            dummy = new OtherClientPlayerEntity(client.world, client.player.getGameProfile());
        }
        if (!ItemStack.areItemsAndComponentsEqual(armor, dummyArmor) || dummySlot != slot) {
            if (dummySlot != null && dummySlot != slot) {
                dummy.equipStack(dummySlot, ItemStack.EMPTY);
            }
            dummy.equipStack(slot, armor.copy());
            dummySlot = slot;
            dummyArmor = armor.copy();
        }
        return dummy;
    }

    /** Vẽ nhân vật của bạn đang mặc giáp kết quả, xoay theo góc hiện tại. (cx, cy) là vị trí chân nhân vật. */
    private static void renderCharacter(DrawContext ctx, MinecraftClient client, ItemStack armor,
                                        EquipmentSlot slot, int cx, int cy) {
        OtherClientPlayerEntity e = ensureDummy(client, armor, slot);
        float yaw = 180f + angleY;
        e.setYaw(yaw);
        e.setBodyYaw(yaw);
        e.setHeadYaw(yaw);

        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(cx, cy, 50.0);
        m.scale(PLAYER_SIZE, PLAYER_SIZE, -PLAYER_SIZE);
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(180f));

        VertexConsumerProvider.Immediate vcp = client.getBufferBuilders().getEntityVertexConsumers();
        client.getEntityRenderDispatcher().setRenderShadows(false);
        client.getEntityRenderDispatcher().render(e, 0.0, 0.0, 0.0, 1.0f, m, vcp,
                LightmapTextureManager.MAX_LIGHT_COORDINATE);
        vcp.draw();
        m.pop();
        ctx.draw();
    }

    /** Vẽ vật phẩm dạng 3D (dùng cho kết quả không phải giáp). */
    private static void renderItem3D(DrawContext ctx, MinecraftClient client, ItemStack stack, int cx, int cy) {
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(cx, cy, 150.0);
        m.scale(56.0f, -56.0f, 56.0f);
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(angleX));
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(angleY));
        VertexConsumerProvider.Immediate vcp = client.getBufferBuilders().getEntityVertexConsumers();
        client.getItemRenderer().renderItem(
                stack,
                ModelTransformationMode.GUI,
                LightmapTextureManager.MAX_LIGHT_COORDINATE,
                OverlayTexture.DEFAULT_UV,
                m,
                vcp,
                client.world,
                0
        );
        vcp.draw();
        m.pop();
        ctx.draw();
    }

    /** Gọi khi nhấn chuột: bắt đầu xoay nếu nhấn bên trong khung xem trước. */
    public static void press(int screenW, int screenH, double mouseX, double mouseY) {
        int px = panelX(screenW) + 4;
        int py = panelY(screenH) + 52;
        dragging = mouseX >= px && mouseX < px + PANEL_W - 8 && mouseY >= py && mouseY < py + PREVIEW_H;
    }

    /** Gọi khi kéo chuột. Trả về true nếu đang xoay (để chặn xử lý khác). */
    public static boolean drag(double deltaX, double deltaY) {
        if (!dragging || !(MinecraftClient.getInstance().currentScreen instanceof SmithingScreen)) {
            return false;
        }
        angleY += (float) deltaX * 1.2f;
        angleX += (float) deltaY * 1.2f;
        if (angleX > 89f) angleX = 89f;
        if (angleX < -89f) angleX = -89f;
        return true;
    }
}
