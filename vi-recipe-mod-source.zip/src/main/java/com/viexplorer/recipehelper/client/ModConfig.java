package com.viexplorer.recipehelper.client;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Cài đặt bật/tắt mod, lưu ở config/vi-recipe-helper.properties. */
public final class ModConfig {

    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("vi-recipe-helper.properties");

    /** Công tắc tổng: tắt thì mọi tính năng đều tắt. */
    public static boolean master = true;
    public static boolean brewing = true;
    public static boolean enchant = true;
    public static boolean smithing = true;
    public static boolean furnace = true;

    private ModConfig() {}

    public static boolean brewingOn() {
        return master && brewing;
    }

    public static boolean enchantOn() {
        return master && enchant;
    }

    public static boolean smithingOn() {
        return master && smithing;
    }

    public static boolean furnaceOn() {
        return master && furnace;
    }

    /** Đọc cài đặt đã lưu; nếu chưa có hoặc lỗi thì giữ mặc định (bật hết). */
    public static void load() {
        if (!Files.exists(FILE)) {
            return;
        }
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(FILE, StandardCharsets.UTF_8)) {
            p.load(r);
        } catch (IOException | RuntimeException e) {
            VIRecipeHelperClient.LOG.error("[vi-recipe-helper] Không đọc được cài đặt, dùng mặc định.", e);
            return;
        }
        master = flag(p, "master");
        brewing = flag(p, "brewing");
        enchant = flag(p, "enchant");
        smithing = flag(p, "smithing");
        furnace = flag(p, "furnace");
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("master", String.valueOf(master));
        p.setProperty("brewing", String.valueOf(brewing));
        p.setProperty("enchant", String.valueOf(enchant));
        p.setProperty("smithing", String.valueOf(smithing));
        p.setProperty("furnace", String.valueOf(furnace));
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer w = Files.newBufferedWriter(FILE, StandardCharsets.UTF_8)) {
                p.store(w, "Vi Recipe Helper");
            }
        } catch (IOException e) {
            VIRecipeHelperClient.LOG.error("[vi-recipe-helper] Không lưu được cài đặt.", e);
        }
    }

    private static boolean flag(Properties p, String key) {
        return !"false".equalsIgnoreCase(p.getProperty(key, "true"));
    }
}
