package com.viexplorer.recipehelper.client;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Danh sách nung trong lò nung: mỗi dòng là một vật phẩm đầu vào và kết quả khi nung.
 * Tên hiển thị lấy theo ngôn ngữ của game; phần "từ khóa" để tìm kiếm bằng tiếng Việt.
 * Đây là danh sách các công thức nung phổ biến của game gốc, không gồm công thức của mod khác.
 */
public final class SmeltingData {

    public record Recipe(ItemStack input, ItemStack output, String keywords) {}

    private static final List<Recipe> ALL = new ArrayList<>();

    static {
        add(Items.RAW_IRON, Items.IRON_INGOT, "sắt thô thỏi sắt");
        add(Items.IRON_ORE, Items.IRON_INGOT, "quặng sắt");
        add(Items.DEEPSLATE_IRON_ORE, Items.IRON_INGOT, "quặng sắt đá sâu");
        add(Items.RAW_GOLD, Items.GOLD_INGOT, "vàng thô thỏi vàng");
        add(Items.GOLD_ORE, Items.GOLD_INGOT, "quặng vàng");
        add(Items.DEEPSLATE_GOLD_ORE, Items.GOLD_INGOT, "quặng vàng đá sâu");
        add(Items.NETHER_GOLD_ORE, Items.GOLD_INGOT, "quặng vàng nether");
        add(Items.RAW_COPPER, Items.COPPER_INGOT, "đồng thô thỏi đồng");
        add(Items.COPPER_ORE, Items.COPPER_INGOT, "quặng đồng");
        add(Items.DEEPSLATE_COPPER_ORE, Items.COPPER_INGOT, "quặng đồng đá sâu");
        add(Items.ANCIENT_DEBRIS, Items.NETHERITE_SCRAP, "mảnh cổ đại netherite");
        add(Items.SAND, Items.GLASS, "cát thủy tinh");
        add(Items.CLAY_BALL, Items.BRICK, "đất sét cục đất sét gạch nung");
        add(Items.CLAY, Items.TERRACOTTA, "khối đất sét đất nung terracotta");
        add(Items.COBBLESTONE, Items.STONE, "đá cuội");
        add(Items.STONE, Items.SMOOTH_STONE, "đá mịn");
        add(Items.STONE_BRICKS, Items.CRACKED_STONE_BRICKS, "gạch đá nứt");
        add(Items.OAK_LOG, Items.CHARCOAL, "gỗ than củi than gỗ");
        add(Items.CACTUS, Items.GREEN_DYE, "xương rồng thuốc nhuộm xanh");
        add(Items.WET_SPONGE, Items.SPONGE, "bọt biển ướt");
        add(Items.CHORUS_FRUIT, Items.POPPED_CHORUS_FRUIT, "quả chorus");
        add(Items.POTATO, Items.BAKED_POTATO, "khoai tây khoai nướng");
        add(Items.BEEF, Items.COOKED_BEEF, "thịt bò bít tết");
        add(Items.PORKCHOP, Items.COOKED_PORKCHOP, "thịt heo thịt lợn");
        add(Items.CHICKEN, Items.COOKED_CHICKEN, "thịt gà");
        add(Items.MUTTON, Items.COOKED_MUTTON, "thịt cừu");
        add(Items.RABBIT, Items.COOKED_RABBIT, "thịt thỏ");
        add(Items.COD, Items.COOKED_COD, "cá tuyết");
        add(Items.SALMON, Items.COOKED_SALMON, "cá hồi");
    }

    private SmeltingData() {}

    private static void add(Item in, Item out, String keywords) {
        ALL.add(new Recipe(new ItemStack(in), new ItemStack(out), keywords));
    }

    /**
     * Tìm công thức: mỗi từ đã gõ phải xuất hiện trong tên đầu vào, tên kết quả hoặc từ khóa.
     * Không gõ gì thì trả về tất cả.
     */
    public static List<Recipe> search(String query) {
        String[] tokens = norm(query).trim().split("\\s+");
        List<Recipe> out = new ArrayList<>();
        for (Recipe r : ALL) {
            if (matches(r, tokens)) {
                out.add(r);
            }
        }
        return out;
    }

    private static boolean matches(Recipe r, String[] tokens) {
        String hay = norm(r.input().getName().getString() + " "
                + r.output().getName().getString() + " " + r.keywords());
        for (String t : tokens) {
            if (!t.isEmpty() && !hay.contains(t)) {
                return false;
            }
        }
        return true;
    }

    /** Chữ thường, bỏ dấu tiếng Việt, đ -> d, để tìm "dat set" cũng ra "đất sét". */
    private static String norm(String s) {
        String t = Normalizer.normalize(s.toLowerCase(Locale.ROOT), Normalizer.Form.NFD);
        return t.replaceAll("\\p{M}", "").replace('đ', 'd');
    }
}
