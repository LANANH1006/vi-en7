package com.viexplorer.recipehelper.client;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWCharModsCallback;
import org.lwjgl.glfw.GLFWCharModsCallbackI;

/**
 * Bắt ký tự gõ vào ở mức cửa sổ (GLFW), không dùng mixin nên không phụ thuộc tên hàm nội bộ của game.
 * Móc nối sau callback của game: ký tự nào ô tìm kiếm đang dùng thì chặn lại,
 * các ký tự còn lại chuyển cho game như bình thường.
 */
public final class CharInput {

    private static boolean installed = false;
    private static GLFWCharModsCallback previous;
    private static GLFWCharModsCallbackI hook; // giữ tham chiếu để callback không bị thu hồi
    private static int received = 0;

    private CharInput() {}

    /** Số ký tự đã nhận từ cửa sổ (dùng để kiểm tra). */
    public static int received() {
        return received;
    }

    /** Gọi mỗi tick; chỉ cài đặt một lần khi cửa sổ game đã có. */
    public static void install() {
        if (installed) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.getWindow() == null) {
            return;
        }
        long handle = client.getWindow().getHandle();
        installed = true;
        hook = (window, codePoint, mods) -> {
            received++;
            if (!handle(codePoint) && previous != null) {
                previous.invoke(window, codePoint, mods);
            }
        };
        previous = GLFW.glfwSetCharModsCallback(handle, hook);
    }

    /** Trả về true nếu ký tự đã được ô tìm kiếm nhận (khi đó game không nhận nữa). */
    private static boolean handle(int codePoint) {
        if (codePoint < 0 || codePoint > 0xFFFF) {
            return false;
        }
        char c = (char) codePoint;
        return BrewingPanel.charTyped(c) || FurnacePanel.charTyped(c);
    }
}
