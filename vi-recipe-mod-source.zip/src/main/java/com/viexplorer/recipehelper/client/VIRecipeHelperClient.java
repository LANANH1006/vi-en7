package com.viexplorer.recipehelper.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.client.gui.screen.ingame.BrewingStandScreen;
import net.minecraft.client.gui.screen.ingame.EnchantmentScreen;
import net.minecraft.client.gui.screen.ingame.FurnaceScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.SmithingScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;
import java.util.Set;
import java.util.function.BooleanSupplier;

public class VIRecipeHelperClient implements ClientModInitializer {

    public static final Logger LOG = LoggerFactory.getLogger("vi-recipe-helper");

    /** Các lỗi đã ghi log, để mỗi lỗi chỉ ghi một lần thay vì lặp lại mỗi khung hình. */
    private static final Set<String> REPORTED = new HashSet<>();

    /** Chạy một đoạn xử lý; nếu lỗi thì ghi log, không để lỗi làm game thoát. */
    static void safe(String where, Runnable action) {
        try {
            action.run();
        } catch (Throwable t) {
            report(where, t);
        }
    }

    static boolean safeBool(String where, BooleanSupplier action) {
        try {
            return action.getAsBoolean();
        } catch (Throwable t) {
            report(where, t);
            return false;
        }
    }

    private static void report(String where, Throwable t) {
        if (REPORTED.add(where)) {
            LOG.error("[vi-recipe-helper] Lỗi trong " + where + " (sẽ không báo lại)", t);
        }
    }

    @Override
    public void onInitializeClient() {
        LOG.info("[vi-recipe-helper] Mod đã được tải.");
        ModConfig.load();

        // Bắt ký tự gõ vào; cài một lần khi cửa sổ game đã sẵn sàng
        ClientTickEvents.START_CLIENT_TICK.register(client -> safe("char-install", CharInput::install));

        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> safe("init-screen", () -> {
            if (screen instanceof BrewingStandScreen && ModConfig.brewingOn()) {
                ScreenEvents.remove(screen);

                ScreenEvents.afterRender(screen).register((s, ctx, mouseX, mouseY, tickDelta) ->
                        safe("brewing-render", () ->
                                BrewingPanel.render(ctx, client.textRenderer, s.width, s.height, mouseX, mouseY)));

                ScreenMouseEvents.allowMouseClick(screen).register((s, mouseX, mouseY, button) -> {
                    safe("brewing-click", () -> BrewingPanel.click(s.width, s.height, mouseX, mouseY));
                    return true;
                });

                ScreenMouseEvents.allowMouseScroll(screen).register((s, mouseX, mouseY, horizontal, vertical) ->
                        !safeBool("brewing-scroll", () ->
                                BrewingPanel.scroll(s.width, s.height, mouseX, mouseY, vertical)));
            } else if (screen instanceof EnchantmentScreen && ModConfig.enchantOn()) {
                ScreenEvents.remove(screen);
                EnchantPanel.reset();

                ScreenEvents.afterRender(screen).register((s, ctx, mouseX, mouseY, tickDelta) ->
                        safe("enchant-render", () -> {
                            ItemStack stack = ((EnchantmentScreen) s).getScreenHandler().getSlot(0).getStack();
                            EnchantPanel.render(ctx, client.textRenderer, client, stack, s.width, s.height, mouseX, mouseY);
                        }));

                ScreenMouseEvents.allowMouseScroll(screen).register((s, mouseX, mouseY, horizontal, vertical) ->
                        !safeBool("enchant-scroll", () ->
                                EnchantPanel.scroll(s.width, s.height, mouseX, mouseY, vertical)));
            } else if (screen instanceof FurnaceScreen && ModConfig.furnaceOn()) {
                ScreenEvents.remove(screen);

                ScreenEvents.afterRender(screen).register((s, ctx, mouseX, mouseY, tickDelta) ->
                        safe("furnace-render", () ->
                                FurnacePanel.render(ctx, client.textRenderer, s.width, s.height, mouseX, mouseY)));

                ScreenMouseEvents.allowMouseClick(screen).register((s, mouseX, mouseY, button) -> {
                    safe("furnace-click", () -> FurnacePanel.click(s.width, s.height, mouseX, mouseY));
                    return true;
                });

                ScreenMouseEvents.allowMouseScroll(screen).register((s, mouseX, mouseY, horizontal, vertical) ->
                        !safeBool("furnace-scroll", () ->
                                FurnacePanel.scroll(s.width, s.height, mouseX, mouseY, vertical)));
            } else if (screen instanceof SmithingScreen && ModConfig.smithingOn()) {
                ScreenEvents.remove(screen);
                SmithingPanel.reset();

                ScreenEvents.afterRender(screen).register((s, ctx, mouseX, mouseY, tickDelta) ->
                        safe("smithing-render", () -> {
                            ScreenHandler handler = ((HandledScreen<?>) s).getScreenHandler();
                            SmithingPanel.render(ctx, client.textRenderer, client, handler, s.width, s.height);
                        }));

                ScreenMouseEvents.allowMouseClick(screen).register((s, mouseX, mouseY, button) -> {
                    safe("smithing-click", () -> SmithingPanel.press(s.width, s.height, mouseX, mouseY));
                    return true;
                });
            }
        }));
    }
}
