package com.viexplorer.recipehelper.mixin;

import com.viexplorer.recipehelper.client.SmithingPanel;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Dự phòng cho trường hợp hàm kéo chuột được khai báo ở Screen. require = 0: nếu không có thì bỏ qua. */
@Mixin(Screen.class)
public abstract class ScreenDragMixin {

    @Inject(method = "mouseDragged", at = @At("HEAD"), cancellable = true, require = 0)
    private void vi$mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY,
                                 CallbackInfoReturnable<Boolean> cir) {
        if (SmithingPanel.drag(deltaX, deltaY)) {
            cir.setReturnValue(true);
        }
    }
}
